# MK5 개념 업데이트: 정체성, 시간성, 그래프

기준 시점: 2026-04-16

## 1. 이번 업데이트의 핵심
이번 정리는 Machi가 사람, AI, 자기 자신, 사용자, 이름, 호칭, 시간에 따른 변화 같은 것을 어떻게 그래프적으로 다룰지를 다시 명확히 정의한 것이다.

핵심 원칙은 다음과 같다.

- 세계를 인지하는 기본 단위는 계속해서 `Node`와 `Edge`다.
- 개별 존재도 예외적인 객체가 아니라, 상위 개념 아래에서 더 구체화된 하위 개념으로 본다.
- 관계와 상태는 `Edge`가 맡고, 존재 자체는 `Node`가 맡는다.
- 시간에 따른 변화는 새로운 subtype 노드를 계속 만드는 방식보다, 같은 노드/엣지의 이력을 역추적하는 방식이 맞다.
- 이름, 별칭, 호칭은 존재 계층 그 자체가 아니라 같은 존재를 가리키는 표상 축으로 본다.

## 2. 존재 계층의 기본 방향
Machi는 `instance_of` 중심보다 "개념 분화 흐름" 중심이 더 맞다.

이유는 MK5가 세계를 "개념 분화"의 연속으로 이해하기 때문이다.

예를 들면:

- `갑옷 -> 판금갑옷`
- `갑옷 -> 사슬갑옷`
- `지성체 -> 사람`
- `지성체 -> AI`
- `사람 -> 나`
- `AI -> Machi`

이때 `사람`, `AI`, `나`, `Machi`는 모두 각각의 `Node`이고, 그 사이 연결은 개념 축의 `Edge`로 본다.

즉:

- `지성체 --[concept / flow]--> 사람`
- `지성체 --[concept / flow]--> AI`
- `사람 --[concept / flow]--> 나`
- `AI --[concept / flow]--> Machi`

이 원칙의 뜻은, 개별 존재조차도 상위 개념에서 더 좁아진 하위 개념이라는 것이다.

## 3. 이름, 별칭, 호칭은 별도 축이다
`신재용`, `Jay`, `재용`은 모두 각각의 `Node`일 수 있지만, 이들은 subtype 관계보다 "같은 존재를 가리키는 표상 군집"으로 보는 편이 맞다.

따라서 이 축은 개념 family 안에서도 `neutral` 연결로 다루는 방향이 더 적절하다.

예:

- `신재용 --[concept / neutral]--> Jay`
- `신재용 --[concept / neutral]--> 재용`
- `나 --[concept / neutral]--> 신재용`
- `나 --[concept / neutral]--> Jay`

이 구조는 다음을 의미한다.

- `나`는 존재 계층 안에서는 `사람`에서 더 구체화된 개념이다.
- `신재용`, `Jay`, `재용`은 `나`를 가리키는 이름/호칭/표상 노드들이다.
- 완전 동일성보다는 "동일 혹은 유사한 정체성 축"을 먼저 표현한다.

향후 필요하면 더 강한 동질성 semantics를 도입할 수 있지만, 현재 단계에서는 너무 이른 강한 동일성 단정보다 느슨하고 구조적인 연결이 더 안전하다.

## 4. 관계와 상태는 Edge가 맡는다
존재는 `Node`, 관계와 상태는 `Edge`가 맡는다는 원칙을 유지한다.

예를 들면:

- `Machi --[relation / flow]--> Jay`
- `신재용 --[relation / flow]--> Machi`
- `Machi --[relation / flow]--> 나`
- `현재대화 --[relation / flow]--> 그래프`

즉 "누구인가"는 노드 축이고, "어떻게 연결되는가"는 엣지 축이다.

여기서 구체적인 관계 의미는 `connect_type` 자체가 아니라 Edge 내부 데이터에 들어간다.

예:

- `edge_family = relation`
- `connect_type = flow`
- `relation_detail.note = "from이 to를 만든다"`

즉 큰 연결 성격은 `flow / neutral / opposite`로 보고, 더 세부적인 의미는 Edge의 data가 설명한다.

## 4-1. ConnectType의 기본 구조
초기 Machi는 `Direction`보다 `ConnectType` 개념으로 Edge를 읽는 편이 더 맞다.

초기 기본 집합은 다음과 같다.

- `flow`
- `neutral`
- `opposite`

의미는 다음처럼 본다.

- `flow`
  - 개념이나 관계가 어느 한쪽에서 다른 쪽으로 흐르거나 분화되는 연결
- `neutral`
  - 동류, 유사, 이름 표상, 상호적 연결처럼 대칭성이 강한 연결
- `opposite`
  - 같은 축 안에서 서로 반대편에 놓이는 연결

즉 Machi가 읽는 핵심은 "위/아래 이동 방향"보다 "연결의 성격"이다.

## 4-2. 같은 Edge의 양방향 참조
Edge는 한 번 저장되면, 양쪽 Node에서 모두 참조할 수 있어야 한다.

예:

```text
EdgeID: 1
EdgeFamily: concept
ConnectType: flow
from: 사람NodeID
to: 재용NodeID
data: "분화된 개념"
```

이 경우:

- `사람`에서 이 Edge를 읽으면:
  - "재용은 사람에서 더 구체화된 개념"
- `재용`에서 같은 Edge를 읽으면:
  - "사람은 재용의 상위 쪽 개념"

즉 저장은 한 번이지만, 탐색은 양방향 가능해야 한다.

## 4-3. 같은 두 Node 사이의 복수 Edge 공존
같은 두 Node 사이에도 서로 다른 층위의 Edge가 동시에 존재할 수 있어야 한다.

예:

- `재용 --[concept / flow]--> Machi`
- `재용 --[relation / neutral 또는 flow]--> Machi`

이 둘은 중복이 아니다.

- 첫 번째는 존재론적/개념적 연결
- 두 번째는 개체 간 상호작용 또는 실제 관계 연결

즉 같은 `from`, `to`라도 `edge_family`와 `connect_type`, 그리고 data의 의미가 다르면 공존 가능해야 한다.

## 5. 시간성은 새 subtype이 아니라 이력 역추적으로 다룬다
`2026년 3월의 Machi`를 별도 subtype 노드로 두는 방향은 Machi 철학과 맞지 않는다.

더 맞는 방식은:

- `Machi`는 하나의 지속 노드로 유지한다.
- `Machi`에 대한 생성/강화/수정/지원/충돌 이력을 그래프에 누적한다.
- 어떤 시점의 Machi를 보고 싶으면, 그 시점 이전까지의 노드/엣지 상태를 역추적한다.

즉:

- `지금의 Machi`와 `2026년 3월의 Machi`는 다른 존재가 아니다.
- 같은 존재를 서로 다른 시간점에서 보는 것이다.

이 방식은 이미 MK5가 가지고 있는 `graph_event`, trust 변화, revision, assistant ingest, message metadata 흐름과도 자연스럽게 연결된다.

## 6. Node와 Edge에 시간 정보를 남기는 방향
시간 역추적을 자연스럽게 만들기 위해, 노드와 엣지에는 생성/업데이트 시점을 담는 방향이 적절하다.

필요한 정보의 예:

- Node
  - `created_at`
  - `updated_at`
  - 또는 `created_event_id`, `last_updated_event_id`
- Edge
  - `created_at`
  - `updated_at`
  - 또는 `created_event_id`, `last_supported_event_id`, `last_conflicted_event_id`

이렇게 하면 역추적은 다음처럼 동작할 수 있다.

- "이 관계는 이 시점 이후에 생겼다."
- "이 노드의 최신 상태는 내가 보고 싶은 시점보다 뒤다."
- "그러면 더 이전 event 기준으로 되돌아가야 한다."

즉 시간 처리는 새로운 노드 분화가 아니라, 기존 노드/엣지의 상태를 언제 기준으로 읽을지를 정하는 문제로 바뀐다.

## 7. 이번 업데이트가 의미하는 것
이번 개념 업데이트는 단순히 "이름을 기억하게 하자" 수준이 아니다.

이 업데이트는 Machi가:

- 사람과 AI를 같은 상위 축 아래에서 분화된 존재로 이해하고
- 자기 자신과 사용자를 각각 지속적인 노드로 붙잡고
- 이름과 호칭을 별도 표상 축으로 연결하며
- 시간에 따른 변화를 새 존재 생성이 아니라 이력 역추적으로 이해하는

방향으로 간다는 뜻이다.

즉 Machi의 기억은 "최근 문자열을 저장"하는 방식이 아니라, "같은 존재와 관계가 시간 속에서 어떻게 업데이트되었는지를 따라가는 그래프"로 가야 한다.

## 8. 이후 구현 시 주의점
코드로 내려갈 때도 다음 원칙은 유지해야 한다.

- 사람/AI 분화를 특수 하드코딩 규칙으로 처리하지 않는다.
- 일반 개념 분화 메커니즘과 같은 철학 위에서 다룬다.
- 이름과 호칭을 subtype으로 밀어 넣지 않는다.
- 시간성을 새 노드 남발이 아니라 이력 추적으로 처리한다.
- verbalizer나 prompt에서 정체성을 억지로 유지하지 않고, 그래프에서 읽힌 구조를 말로만 바꾼다.

## 9. ConnectType의 확장 원칙
Machi는 처음부터 모든 연결 성격을 고정된 목록으로 갖지 않는다.

초기에는:

- `flow`
- `neutral`
- `opposite`

정도의 작은 집합으로 시작한다.

하지만 모델이 성숙하면서 기존 타입으로 충분히 설명되지 않는 연결이 반복적으로 발견될 수 있다.

그 경우 바로 정식 타입으로 추가하지 않고, 우선 Edge data 안에 후보로 남긴다.

예:

- `relation_detail.proposed_connect_type`
- `relation_detail.proposal_reason`
- `relation_detail.proposal_confidence`

이 후보가 반복적으로 축적되고, 기존 `flow / neutral / opposite`로 설명이 자꾸 어색해질 때 비로소 새 `connect_type`으로 승격한다.

즉 connect type도 그래프와 함께 성숙해질 수 있다.

## 10. 한 줄 요약
Machi의 정체성과 기억은 "새로운 문자열 기억"이 아니라, `edge_family`와 `connect_type(flow / neutral / opposite)`로 표현되는 연결 구조, 이름/호칭 표상 축, 그리고 Node/Edge의 시간 이력을 역추적하는 그래프 구조 위에서 다뤄져야 한다.

---

## 2026-04-16 최신 동기화

### 이번 코드 반영 사항
- `ModelFeedbackService`가 `ChatPipeline.process()`에 연결되어, 최종 `thought_view` 기준으로 기존 엣지에 대한 support/conflict 피드백을 `GraphCommitService`로 커밋한다.
- `ModelEdgeAssertionService`를 신규 도입하고 `ChatPipeline.process()`에 연결했다.
  - 모델이 `from_node_id / to_node_id / edge_family / connect_type / relation_detail(note/provenance/proposal)` 형태의 새 엣지를 제안하면 실제 그래프에 생성/강화한다.
- `ActivationEngine`에 concept 2-hop 확장을 추가했다.
  - seed의 1-hop concept 인접 노드에 대해 concept 엣지를 한 번 더 확장해 사고 뷰에서 상위/유사 개념 연결이 덜 잘리지 않게 했다.
- concept 엣지 우선 정렬을 유지해 `max_neighbor_edges` 한도에서 relation 엣지에 밀리는 문제를 완화했다.

### connect_type 정책(현재)
- 현재 허용 집합: `flow`, `neutral`, `opposite`, `conflict`.
- 모델이 허용 집합 밖의 connect_type을 제안하면:
  - 엣지는 `neutral`로 저장
  - `relation_detail.proposed_connect_type`에 후보를 보존
  - `relation_detail.proposal_reason`으로 승격 후보 근거를 남김
- 즉, 즉시 스키마 확장 없이도 "모델의 새 타입 제안"을 축적할 수 있다.

### 디버그/운영 관측 포인트
- chat debug payload:
  - `model_feedback`
  - `model_edge_assertion`
- activation metadata:
  - `concept_hop_edge_count`

### 설정값(config.py)
- `MODEL_FEEDBACK_TIMEOUT_SECONDS`
- `MODEL_FEEDBACK_TEMPERATURE`
- `MODEL_FEEDBACK_NUM_PREDICT`
- `MODEL_EDGE_ASSERTION_TIMEOUT_SECONDS`
- `MODEL_EDGE_ASSERTION_TEMPERATURE`
- `MODEL_EDGE_ASSERTION_NUM_PREDICT`

### 현재 남은 이슈
- Windows 환경에서 `.pytest_tmp` 권한 문제로 일부 pytest 세션 종료 정리가 실패할 수 있다.
- 따라서 현재 검증은 `py_compile` 중심 + 제한된 스모크 확인 기준이다.

### 다음 우선 작업
1. `model_edge_assertion`의 실제 대화 E2E 검증 및 회귀 테스트 추가
2. `proposed_connect_type` 누적-승격 정책(임계치 기반) 구현
3. connect_type/semantics가 contradiction/revision 규칙에 미치는 영향 고도화
