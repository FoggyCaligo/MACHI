# Unified chat route placeholder
