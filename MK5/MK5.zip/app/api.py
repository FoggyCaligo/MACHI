from __future__ import annotations

from pathlib import Path

from flask import Flask, jsonify, request, send_from_directory

from core.activation.activation_engine import ActivationEngine, ActivationRequest
from core.thinking.thought_engine import ThoughtEngine, ThoughtRequest
from core.update.graph_ingest_service import GraphIngestRequest, GraphIngestService
from storage.sqlite.unit_of_work import SqliteUnitOfWork

PROJECT_ROOT = Path(__file__).resolve().parents[1]
DB_PATH = PROJECT_ROOT / 'data' / 'memory.db'
SCHEMA_PATH = PROJECT_ROOT / 'storage' / 'schema.sql'
REQUEST_TIMEOUT_MS = 300000


def _uow_factory():
    return SqliteUnitOfWork(DB_PATH, schema_path=SCHEMA_PATH, initialize_schema=True)


def register_routes(app: Flask) -> None:
    ingest_service = GraphIngestService(_uow_factory)
    activation_engine = ActivationEngine(_uow_factory)
    thought_engine = ThoughtEngine(_uow_factory)

    @app.get('/')
    def index():
        return send_from_directory(app.static_folder, 'chat.html')

    @app.get('/ui-config')
    def ui_config():
        return jsonify({'request_timeout_ms': REQUEST_TIMEOUT_MS})

    @app.get('/projects')
    def projects():
        return jsonify({'projects': []})

    @app.get('/models')
    def models():
        return jsonify(
            {
                'default_model': 'mk5-graph-core',
                'models': [],
                'ollama_available': False,
                'error': None,
            }
        )

    @app.post('/chat')
    def chat():
        message = (request.form.get('message') or '').strip()
        if not message:
            return jsonify({'detail': 'message is required'}), 400

        session_id = (request.form.get('session_id') or 'default').strip() or 'default'
        turn_index = _next_turn_index(session_id)
        file = request.files.get('file')
        attached_files = []
        if file and file.filename:
            attached_files.append({'name': file.filename, 'size': getattr(file, 'content_length', None)})

        ingest_result = ingest_service.ingest(
            GraphIngestRequest(
                session_id=session_id,
                turn_index=turn_index,
                role='user',
                content=message,
                attached_files=attached_files,
                metadata={'source': 'ui_chat'},
            )
        )
        thought_view = activation_engine.build_view(
            ActivationRequest(
                session_id=session_id,
                content=message,
            )
        )
        thought_result = thought_engine.think(
            ThoughtRequest(
                session_id=session_id,
                message_id=ingest_result.message_id,
                message_text=message,
            ),
            thought_view,
        )

        reply = thought_result.summary
        return jsonify(
            {
                'reply': reply,
                'used_model': 'mk5-graph-core',
                'project_id': None,
                'project_name': None,
                'ingest': {
                    'message_id': ingest_result.message_id,
                    'root_event_id': ingest_result.root_event_id,
                    'block_count': ingest_result.block_count,
                    'created_node_ids': ingest_result.created_node_ids,
                    'reused_node_ids': ingest_result.reused_node_ids,
                },
                'thinking': {
                    'signal_count': len(thought_result.contradiction_signals),
                    'revision_action_count': len(thought_result.revision_actions),
                    'metadata': thought_result.metadata,
                },
            }
        )

    def _next_turn_index(session_id: str) -> int:
        with _uow_factory() as uow:
            rows = list(uow.chat_messages.list_by_session(session_id, limit=100000))
            return (rows[-1].turn_index + 1) if rows else 1
