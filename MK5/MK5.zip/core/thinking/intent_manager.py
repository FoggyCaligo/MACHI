# Intent manager placeholder
