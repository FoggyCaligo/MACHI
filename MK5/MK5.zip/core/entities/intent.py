# Intent entity placeholder
