from __future__ import annotations

from dataclasses import dataclass

from core.entities.conclusion import CoreConclusion
from core.verbalization.template_verbalizer import TemplateVerbalizer


@dataclass(slots=True)
class VerbalizationResult:
    user_response: str
    internal_explanation: str


@dataclass(slots=True)
class Verbalizer:
    template_verbalizer: TemplateVerbalizer | None = None

    def __post_init__(self) -> None:
        if self.template_verbalizer is None:
            self.template_verbalizer = TemplateVerbalizer()

    def verbalize(self, conclusion: CoreConclusion) -> VerbalizationResult:
        return VerbalizationResult(
            user_response=self.template_verbalizer.build_user_response(conclusion),
            internal_explanation=self.template_verbalizer.build_internal_explanation(conclusion),
        )
