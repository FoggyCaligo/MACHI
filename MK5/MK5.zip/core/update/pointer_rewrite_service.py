# Pointer rewrite placeholder
