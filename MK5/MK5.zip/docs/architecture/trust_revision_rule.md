# Trust revision rule

Placeholder.
