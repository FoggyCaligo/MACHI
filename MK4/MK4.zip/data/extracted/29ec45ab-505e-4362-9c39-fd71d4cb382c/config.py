from pathlib import Path
import os
from dataclasses import dataclass
from dotenv import load_dotenv

load_dotenv()

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
PROMPTS_DIR = BASE_DIR / "prompts"

DB_PATH = DATA_DIR / "memory.db"

SYSTEM_PROMPT_PATH = PROMPTS_DIR / "system_prompt.txt"
PROJECT_ASK_SYSTEM_PROMPT_PATH = PROMPTS_DIR / "project_ask_system_prompt.txt"
REVIEW_SYSTEM_PROMPT_PATH = PROMPTS_DIR / "review_system_prompt.txt"
PROFILE_EXTRACT_SYSTEM_PROMPT_PATH = PROMPTS_DIR / "profile_extract_system_prompt.txt"
PROJECT_PROFILE_EVIDENCE_EXTRACT_SYSTEM_PROMPT_PATH = (
    PROMPTS_DIR / "project_profile_evidence_extract_system_prompt.txt"
)
PROJECT_PROFILE_EVIDENCE_ANSWER_SYSTEM_PROMPT_PATH = (
    PROMPTS_DIR / "project_profile_evidence_answer_system_prompt.txt"
)
PROJECT_PROFILE_ROUTE_SYSTEM_PROMPT_PATH = (
    PROMPTS_DIR / "project_profile_route_system_prompt.txt"
)
PROFILE_ATTACHMENT_ANSWER_SYSTEM_PROMPT_PATH = (
    PROMPTS_DIR / "profile_attachment_answer_system_prompt.txt"
)
CHAT_UPDATE_EXTRACT_SYSTEM_PROMPT_PATH = (
    PROMPTS_DIR / "chat_update_extract_system_prompt.txt"
)

OLLAMA_BASE_URL = "http://localhost:11434"
OLLAMA_DEFAULT_MODEL = "qwen2.5:3b"
OLLAMA_MODEL = OLLAMA_DEFAULT_MODEL

# Trusted Search 설정
OLLAMA_API_KEY = ""  # 환경변수에서 읽어올 예정
OLLAMA_WEB_SEARCH_URL = "https://ollama.com/api/web_search"
INTERNET_SEARCH_ENABLED = True
MAX_SEARCH_RESULTS = 8

TOPIC_EMBEDDING_MODEL = "intfloat/multilingual-e5-small"
KEEP_ACTIVE_THRESHOLD = 0.73
ATTACH_EXISTING_THRESHOLD = 0.78
PROFILE_SEMANTIC_CLUSTER_THRESHOLD = 0.80
PROFILE_SEMANTIC_MATCH_THRESHOLD = 0.84
PROFILE_REPLACEMENT_SCORE_TOLERANCE = 0.05
PROFILE_HISTORY_KEEP_SUPERSEDED = 1
GENERAL_RETENTION_DAYS = 90
TOPIC_SUMMARY_SENTENCE_COUNT = 2
TOPIC_SIMILARITY_CANDIDATE_LIMIT = 12

TOPIC_ROUTER_TIMEOUT = 45
TOPIC_ROUTER_NUM_PREDICT = 256
TOPIC_CREATE_MIN_CONFIDENCE = 0.55
TOPIC_CONFIRM_MIN_CONFIDENCE = 0.75

# 라우팅 분류 (텍스트/프로젝트 경로 판단)
ROUTE_CLASSIFY_NUM_PREDICT = 96


@dataclass(frozen=True)
class Settings:
    ollama_api_key: str = os.getenv("OLLAMA_API_KEY", "")
    ollama_web_search_url: str = os.getenv("OLLAMA_WEB_SEARCH_URL", "https://ollama.com/api/web_search")
    internet_search_enabled: bool = os.getenv("INTERNET_SEARCH_ENABLED", "true").lower() == "true"
    max_search_results: int = int(os.getenv("MAX_SEARCH_RESULTS", "8"))


settings = Settings()

# Evidence 추출 (JSON 구조 생성)
EXTRACT_NUM_PREDICT = 384
EXTRACT_RETRY_NUM_PREDICT = 256

GENERAL_REPLY_TIMEOUT = 240
GENERAL_REPLY_NUM_PREDICT = 768
GENERAL_REPLY_MAX_CONTINUATIONS = 1

ATTACHMENT_REPLY_TIMEOUT = 120
ATTACHMENT_REPLY_NUM_PREDICT = 768
ATTACHMENT_REPLY_MAX_CONTINUATIONS = 1

PROJECT_REPLY_TIMEOUT = 120
PROJECT_REPLY_NUM_PREDICT = 768
PROJECT_REPLY_MAX_CONTINUATIONS = 1
