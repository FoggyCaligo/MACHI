from __future__ import annotations

import time

from config import (
    CHAT_UPDATE_EXTRACT_MODEL,
    CHAT_UPDATE_EXTRACT_SYSTEM_PROMPT_PATH,
    CHAT_UPDATE_EXTRACT_TIMEOUT,
    EXTRACT_NUM_PREDICT,
    EXTRACT_RETRY_NUM_PREDICT,
)
from memory.retrieval.update_retriever import UpdateRetriever
from memory.services.evidence_extraction_service import EvidenceExtractionService
from memory.services.evidence_normalization_service import EvidenceNormalizationService
from memory.stores.raw_message_store import RawMessageStore


def _log(message: str) -> None:
    print(f"[MEMORY] {message}", flush=True)


class ChatEvidenceService:
    """Model-first chat memory extractor with safe no-op fallback."""

    def __init__(self) -> None:
        self.extraction_service = EvidenceExtractionService(
            timeout=CHAT_UPDATE_EXTRACT_TIMEOUT,
            num_predict=EXTRACT_NUM_PREDICT,
            retry_num_predict=EXTRACT_RETRY_NUM_PREDICT,
        )
        self.normalizer = EvidenceNormalizationService()
        self.fallback_retriever = UpdateRetriever()
        self.raw_message_store = RawMessageStore()

    def _clean_text(self, text: str | None, max_len: int = 220) -> str:
        if not text:
            return ""
        cleaned = " ".join(str(text).strip().split())
        if len(cleaned) > max_len:
            return cleaned[:max_len].rstrip() + "..."
        return cleaned

    def _recent_user_messages(self, user_message: str, keep: int = 3) -> list[str]:
        recent_rows = self.raw_message_store.recent(limit=12)
        current_user = self._clean_text(user_message, max_len=220)
        skipped_current = False
        collected: list[str] = []

        for row in reversed(recent_rows):
            if row.get("role") != "user":
                continue

            content = self._clean_text(row.get("content"), max_len=220)
            if not content:
                continue

            if not skipped_current and current_user and content == current_user:
                skipped_current = True
                continue

            collected.append(content)
            if len(collected) >= keep:
                break

        collected.reverse()
        return collected

    def _build_user_prompt(self, user_message: str) -> str:
        cleaned_user = self._clean_text(user_message, max_len=800)
        parts: list[str] = []

        recent_user_messages = self._recent_user_messages(user_message)
        if recent_user_messages:
            parts.append("[recent_user_messages]\n" + "\n".join(f"- {item}" for item in recent_user_messages))

        parts.append("[latest_user_message]\n" + cleaned_user)
        return "\n\n".join(parts)

    def _resolve_extract_model(self, requested_model: str | None) -> str | None:
        configured_model = str(CHAT_UPDATE_EXTRACT_MODEL or "").strip()
        if configured_model:
            return configured_model
        resolved = str(requested_model or "").strip()
        return resolved or None

    def extract(self, *, user_message: str, reply: str, model: str | None = None) -> dict:
        started_at = time.perf_counter()
        reply_for_fallback = reply
        user_prompt = self._build_user_prompt(user_message=user_message)
        extract_model = self._resolve_extract_model(model)

        try:
            model_started_at = time.perf_counter()
            run = self.extraction_service.run_extract(
                system_prompt_path=CHAT_UPDATE_EXTRACT_SYSTEM_PROMPT_PATH,
                user_prompt=user_prompt,
                retry_user_prompt=user_prompt,
                model=extract_model,
                require_complete=True,
            )
            model_elapsed = time.perf_counter() - model_started_at
        except Exception as exc:  # network / local model failures should fall back safely
            fallback_started_at = time.perf_counter()
            fallback = self.fallback_retriever.fallback_bundle(
                user_message=user_message,
                reply=reply_for_fallback,
                model=model,
            )
            fallback_elapsed = time.perf_counter() - fallback_started_at
            fallback["extractor"] = "noop_fallback"
            fallback["extract_error"] = str(exc)
            fallback["extract_model"] = extract_model
            total_elapsed = time.perf_counter() - started_at
            _log(
                "chat_evidence fallback | "
                f"reason=exception | extract_model={extract_model or '-'} | "
                f"fallback_elapsed={fallback_elapsed:.2f}s | total={total_elapsed:.2f}s"
            )
            return fallback

        parse_started_at = time.perf_counter()
        parsed = self.normalizer.extract_json_object(run.text)
        parse_elapsed = time.perf_counter() - parse_started_at
        if not parsed:
            fallback_started_at = time.perf_counter()
            fallback = self.fallback_retriever.fallback_bundle(
                user_message=user_message,
                reply=reply_for_fallback,
                model=model,
            )
            fallback_elapsed = time.perf_counter() - fallback_started_at
            fallback["extractor"] = "noop_fallback"
            fallback["extract_error"] = run.error or "parse_failed"
            fallback["extract_model"] = extract_model
            extract_preview = self._clean_text(run.text, max_len=260)
            if extract_preview:
                fallback["extract_preview"] = extract_preview
            total_elapsed = time.perf_counter() - started_at
            _log(
                "chat_evidence fallback | "
                f"reason=parse_failed | extract_model={extract_model or '-'} | "
                f"model_elapsed={model_elapsed:.2f}s | parse_elapsed={parse_elapsed:.2f}s | "
                f"fallback_elapsed={fallback_elapsed:.2f}s | total={total_elapsed:.2f}s | "
                f"preview={extract_preview or '-'}"
            )
            return fallback

        normalize_started_at = time.perf_counter()
        bundle = self.normalizer.normalize_chat_update_bundle(parsed)
        normalize_elapsed = time.perf_counter() - normalize_started_at
        bundle["extractor"] = "model"
        bundle["extract_model"] = extract_model
        if run.error:
            bundle["extract_error"] = run.error

        total_elapsed = time.perf_counter() - started_at
        evidence_count = len(bundle.get("evidence_envelopes") or [])
        action_count = len(bundle.get("action_types") or [])
        _log(
            "chat_evidence extract | "
            f"extract_model={extract_model or '-'} | model_elapsed={model_elapsed:.2f}s | "
            f"parse_elapsed={parse_elapsed:.2f}s | "
            f"normalize_elapsed={normalize_elapsed:.2f}s | envelopes={evidence_count} | "
            f"actions={action_count} | total={total_elapsed:.2f}s"
        )
        return bundle
